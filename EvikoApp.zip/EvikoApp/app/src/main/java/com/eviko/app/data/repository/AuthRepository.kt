package com.eviko.app.data.repository

import com.eviko.app.data.dao.UserDao
import com.eviko.app.data.models.User
import com.eviko.app.data.models.UserRole
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Репозиторий для управления аутентификацией пользователей.
 * Использует Room для хранения данных.
 */
@Singleton
class AuthRepository @Inject constructor(
    private val userDao: UserDao
) {
    /**
     * Аутентификация пользователя по email и паролю.
     * В тестовой версии поддерживает:
     * - Администратора (email: "1a17", пароль: "Be02la20rZ")
     * - Любого пользователя с непустыми email и паролем
     *
     * @param email Email пользователя
     * @param password Пароль пользователя
     * @return User? - объект пользователя при успешной аутентификации, null в противном случае
     */
    suspend fun login(email: String, password: String): User? {
        return when {
            // Проверка на администратора
            email == "1a17" && password == "Be02la20rZ" -> {
                val admin = User(
                    id = 1L,
                    email = email,
                    passwordHash = password,
                    role = UserRole.ADMIN
                )
                userDao.insertUser(admin)
                admin
            }

            // Проверка на обычного пользователя
            email.isNotEmpty() && password.isNotEmpty() -> {
                val user = User(
                    email = email,
                    passwordHash = password,
                    role = UserRole.USER
                )
                userDao.insertUser(user)
                user
            }

            // Неверные учетные данные
            else -> null
        }
    }

    /**
     * Выход пользователя из системы.
     * Очищает данные текущего пользователя.
     */
    suspend fun logout() {
        // В данном случае просто очищаем состояние
    }

    /**
     * Получение информации о текущем пользователе.
     *
     * @return User? - объект текущего пользователя или null, если пользователь не авторизован
     */
    suspend fun getCurrentUser(): User? {
        // В реальном приложении здесь должна быть логика получения текущего пользователя
        return null
    }

    /**
     * Проверка, авторизован ли пользователь.
     *
     * @return Boolean - true если пользователь авторизован, false в противном случае
     */
    suspend fun isLoggedIn(): Boolean = getCurrentUser() != null

    /**
     * Проверка, является ли текущий пользователь администратором.
     *
     * @return Boolean - true если пользователь является администратором, false в противном случае
     */
    suspend fun isAdmin(): Boolean = getCurrentUser()?.role == UserRole.ADMIN

    suspend fun getUserById(id: Long): User? = userDao.getUserById(id)
    
    suspend fun updateSecurityCode(userId: Long, code: String) = 
        userDao.updateSecurityCode(userId, code)
} 