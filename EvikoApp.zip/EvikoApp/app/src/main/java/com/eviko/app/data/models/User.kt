package com.eviko.app.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    GUEST,
    USER,
    ADMIN
}

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val email: String,
    val passwordHash: String,
    val role: UserRole,
    val securityCode: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) 