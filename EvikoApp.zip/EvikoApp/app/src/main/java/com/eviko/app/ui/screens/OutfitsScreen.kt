package com.eviko.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutfitsScreen() {
    var selectedCategory by remember { mutableStateOf("Tops") }
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Категории
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory),
            modifier = Modifier.fillMaxWidth()
        ) {
            categories.forEach { category ->
                Tab(
                    selected = category == selectedCategory,
                    onClick = { selectedCategory = category },
                    text = { Text(category) }
                )
            }
        }

        // Товары
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(
                when (selectedCategory) {
                    "Tops" -> tops
                    "Bottoms" -> bottoms
                    "Shoes" -> shoes
                    else -> emptyList()
                }
            ) { item ->
                ProductCard(item)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductCard(product: Product) {
    Card(
        onClick = { /* TODO: Открыть детали */ },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Image(
                painter = painterResource(id = product.imageRes),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier.padding(8.dp)
            ) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "${product.price} €",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

private data class Product(
    val imageRes: Int,
    val name: String,
    val price: Int
)

private val categories = listOf("Tops", "Bottoms", "Shoes", "Accessories")

// Примеры данных (замените на реальные ресурсы)
private val tops = listOf(
    Product(android.R.drawable.ic_menu_gallery, "PUMA X KIDSUPER PROGRESSIVE", 165),
    Product(android.R.drawable.ic_menu_gallery, "BUTTER GOODS JIVE FLANNEL JACKET", 150),
    Product(android.R.drawable.ic_menu_gallery, "BUTTER GOODS ALPINE TEE", 48)
)

private val bottoms = listOf(
    Product(android.R.drawable.ic_menu_gallery, "DICKIES RIVERBEND CARGO WORK PANT", 85),
    Product(android.R.drawable.ic_menu_gallery, "NIKE SOLO SWOOSH FLEECE PANTS", 90),
    Product(android.R.drawable.ic_menu_gallery, "CARHARTT WIP DOUBLE KNEE PANTS", 129)
)

private val shoes = listOf(
    Product(android.R.drawable.ic_menu_gallery, "A BATHING APE BAPE STA ICON", 315),
    Product(android.R.drawable.ic_menu_gallery, "SAUCONY PROGRID OMNI 9 GREY SUEDE", 170),
    Product(android.R.drawable.ic_menu_gallery, "VANS KNU SKOOL BEIGE BROWN", 95)
) 