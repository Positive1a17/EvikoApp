package com.eviko.app.data.repositories

import com.eviko.app.data.models.User
import com.eviko.app.data.models.UserRole
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor() {
    private var currentUser: User? = null

    fun login(email: String, password: String): User? {
        return when {
            email == "1a17" && password == "Be02la20rZ" -> {
                User(
                    id = "admin",
                    email = email,
                    role = UserRole.ADMIN,
                    name = "Administrator"
                ).also { currentUser = it }
            }

            email.isNotEmpty() && password.isNotEmpty() -> {
                User(
                    id = "user_${email.hashCode()}",
                    email = email,
                    role = UserRole.USER,
                    name = email.split("@").first()
                ).also { currentUser = it }
            }

            else -> null
        }
    }

    fun logout() {
        currentUser = null
    }

    fun getCurrentUser(): User? = currentUser

    fun isLoggedIn(): Boolean = currentUser != null

    fun isAdmin(): Boolean = currentUser?.role == UserRole.ADMIN
} 