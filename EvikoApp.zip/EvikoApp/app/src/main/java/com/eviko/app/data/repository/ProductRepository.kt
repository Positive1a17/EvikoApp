package com.eviko.app.data.repository

import com.eviko.app.data.dao.ProductDao
import com.eviko.app.data.dao.CategoryDao
import com.eviko.app.data.models.Product
import com.eviko.app.data.models.Category
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Репозиторий для работы с продуктами и категориями.
 * В тестовой версии хранит данные в памяти устройства.
 */
@Singleton
class ProductRepository @Inject constructor(
    private val productDao: ProductDao,
    private val categoryDao: CategoryDao
) {
    /**
     * Получение списка всех продуктов.
     *
     * @return List<Product> - список всех доступных продуктов
     */
    fun getAllProducts(): Flow<List<Product>> = productDao.getAllProducts()
    
    /**
     * Получение списка продуктов по категории.
     *
     * @param categoryId ID категории
     * @return List<Product> - список продуктов в указанной категории
     */
    fun getProductsByCategory(categoryId: Long): Flow<List<Product>> = 
        productDao.getProductsByCategory(categoryId)
    
    /**
     * Поиск продуктов по запросу.
     *
     * @param query Поисковый запрос
     * @return List<Product> - список продуктов, соответствующих запросу
     */
    fun searchProducts(query: String): Flow<List<Product>> = 
        productDao.searchProducts(query)
    
    /**
     * Получение продукта по ID.
     *
     * @param id ID продукта
     * @return Product? - продукт с указанным ID или null, если не найден
     */
    suspend fun getProductById(id: Long): Product? = productDao.getProductById(id)
    
    /**
     * Получение списка всех категорий.
     *
     * @return List<Category> - список всех доступных категорий
     */
    fun getAllCategories(): Flow<List<Category>> = categoryDao.getAllCategories()
    
    /**
     * Получение категории по ID.
     *
     * @param id ID категории
     * @return Category? - категория с указанным ID или null, если не найдена
     */
    suspend fun getCategoryById(id: Long): Category? = categoryDao.getCategoryById(id)
    
    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)
    
    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)
    
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)
    
    suspend fun insertCategory(category: Category): Long = categoryDao.insertCategory(category)
    
    suspend fun updateCategory(category: Category) = categoryDao.updateCategory(category)
    
    suspend fun deleteCategory(category: Category) = categoryDao.deleteCategory(category)
} 