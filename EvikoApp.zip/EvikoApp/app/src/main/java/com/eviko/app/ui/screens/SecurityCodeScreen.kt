package com.eviko.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.eviko.app.R
import com.eviko.app.ui.viewmodels.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityCodeScreen(
    navController: NavController,
    viewModel: MainViewModel
) {
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.security_code)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.enter_security_code),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            OutlinedTextField(
                value = code,
                onValueChange = { 
                    if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                        code = it
                    }
                },
                label = { Text(stringResource(R.string.security_code)) },
                keyboardType = KeyboardType.Number,
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                isError = error != null
            )

            if (error != null) {
                Text(
                    text = error!!,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    if (code.length == 4) {
                        viewModel.verifySecurityCode(code) { success ->
                            if (success) {
                                navController.navigate("home") {
                                    popUpTo("security_code") { inclusive = true }
                                }
                            } else {
                                error = stringResource(R.string.invalid_code)
                            }
                        }
                    } else {
                        error = stringResource(R.string.code_length_error)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = code.length == 4
            ) {
                Text(stringResource(R.string.verify))
            }

            TextButton(
                onClick = { viewModel.logout() },
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text(stringResource(R.string.logout))
            }
        }
    }
} 