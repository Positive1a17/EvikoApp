package com.eviko.app.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MainUiState(
    val isLoading: Boolean = false,
    val currentUser: String? = null,
    val error: String? = null
)

@HiltViewModel
class MainViewModel @Inject constructor() : ViewModel() {
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var currentUser: String? = null
    private var currentLanguage: String = "en"
    private var currentTheme: String = "system"

    fun getCurrentUser(): String? = _uiState.value.currentUser

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            // Здесь будет реальная логика авторизации
            currentUser = email
            _uiState.value = _uiState.value.copy(currentUser = email)
        }
    }

    fun logout() {
        viewModelScope.launch {
            currentUser = null
            _uiState.value = _uiState.value.copy(currentUser = null)
        }
    }

    fun getCurrentLanguage(): String = currentLanguage

    fun setLanguage(language: String) {
        currentLanguage = language
        // Здесь будет логика изменения языка
    }

    fun getCurrentTheme(): String = currentTheme

    fun setTheme(theme: String) {
        currentTheme = theme
        // Здесь будет логика изменения темы
    }
} 