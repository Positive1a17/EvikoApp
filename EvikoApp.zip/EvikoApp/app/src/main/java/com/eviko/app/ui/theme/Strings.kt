package com.eviko.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration

data class Strings(
    val appName: String,
    val welcome: String,
    val login: String,
    val logout: String,
    val email: String,
    val password: String,
    val cart: String,
    val addToCart: String,
    val remove: String,
    val checkout: String,
    val total: String,
    val back: String,
    val adminPanel: String,
    val settings: String,
    val language: String,
    val theme: String,
    val darkTheme: String,
    val lightTheme: String,
    val russian: String,
    val english: String
)

val LocalStrings = staticCompositionLocalOf {
    Strings(
        appName = TODO(),
        welcome = TODO(),
        login = TODO(),
        logout = TODO(),
        email = TODO(),
        password = TODO(),
        cart = TODO(),
        addToCart = TODO(),
        remove = TODO(),
        checkout = TODO(),
        total = TODO(),
        back = TODO(),
        adminPanel = TODO(),
        settings = TODO(),
        language = TODO(),
        theme = TODO(),
        darkTheme = TODO(),
        lightTheme = TODO(),
        russian = TODO(),
        english = TODO()
    )
}

@Composable
fun getStrings(): Strings {
    val locale = LocalConfiguration.current.locales[0]
    return when (locale.language) {
        "ru" -> RussianStrings
        else -> EnglishStrings
    }
}

private val EnglishStrings = Strings(
    appName = "Eviko",
    welcome = "Welcome to Eviko",
    login = "Login",
    logout = "Logout",
    email = "Email",
    password = "Password",
    cart = "Cart",
    addToCart = "Add to Cart",
    remove = "Remove",
    checkout = "Checkout",
    total = "Total",
    back = "Back",
    adminPanel = "Admin Panel",
    settings = "Settings",
    language = "Language",
    theme = "Theme",
    darkTheme = "Dark Theme",
    lightTheme = "Light Theme",
    russian = "Russian",
    english = "English"
)

private val RussianStrings = Strings(
    appName = "Эвико",
    welcome = "Добро пожаловать в Эвико",
    login = "Войти",
    logout = "Выйти",
    email = "Электронная почта",
    password = "Пароль",
    cart = "Корзина",
    addToCart = "Добавить в корзину",
    remove = "Удалить",
    checkout = "Оформить заказ",
    total = "Итого",
    back = "Назад",
    adminPanel = "Панель администратора",
    settings = "Настройки",
    language = "Язык",
    theme = "Тема",
    darkTheme = "Тёмная тема",
    lightTheme = "Светлая тема",
    russian = "Русский",
    english = "Английский"
) 