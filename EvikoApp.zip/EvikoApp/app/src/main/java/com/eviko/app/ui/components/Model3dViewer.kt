package com.eviko.app.ui.components

import android.content.Context
import android.view.MotionEvent
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.filament.Engine
import com.google.android.filament.View
import com.google.android.filament.android.DisplayHelper
import com.google.android.filament.android.TextureHelper
import com.google.android.filament.utils.ModelViewer
import com.google.android.filament.utils.Utils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.channels.Channels
import java.io.InputStream

/**
 * Компонент для отображения 3D моделей с использованием Filament.
 * Поддерживает дневное и ночное освещение.
 *
 * @param modelUrl URL 3D модели в формате GLB
 * @param isDarkMode Флаг темной темы
 */
@Composable
fun Model3dViewer(
    modifier: Modifier = Modifier,
    modelUrl: String,
    isDarkMode: Boolean = false
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var modelViewer by remember { mutableStateOf<ModelViewer?>(null) }
    var displayHelper by remember { mutableStateOf<DisplayHelper?>(null) }

    DisposableEffect(lifecycleOwner) {
        Utils.init()
        onDispose {
            Utils.cleanup()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    modelViewer?.let { viewer ->
                        viewer.cameraManipulator?.rotate(
                            dragAmount.x * 0.01f,
                            dragAmount.y * 0.01f
                        )
                    }
                }
            }
            .pointerInput(Unit) {
                detectTransformGestures { centroid, pan, zoom, rotationChange ->
                    modelViewer?.let { viewer ->
                        viewer.cameraManipulator?.apply {
                            rotate(rotationChange, 0f)
                            zoom(zoom)
                            pan(pan.x, pan.y)
                        }
                    }
                }
            }
    ) {
        AndroidView(
            factory = { context ->
                val surfaceView = SurfaceView(context).apply {
                    setBackgroundColor(Color.Transparent.toArgb())
                }
                surfaceView
            },
            modifier = Modifier.fillMaxSize(),
            update = { view ->
                if (modelViewer == null) {
                    modelViewer = ModelViewer(view).apply {
                        layoutParams = android.view.ViewGroup.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        loadModelGlb(context.assets, "3d_models/$modelUrl")
                        transformToUnitCube()
                        setCameraManipulator(OrbitManipulator())
                        setIndirectLight(IndirectLight.Builder()
                            .intensity(if (isDarkMode) 0.1f else 1.0f)
                            .build())
                        setDirectLight(DirectLight.Builder()
                            .intensity(if (isDarkMode) 0.1f else 1.0f)
                            .build())
                    }
                }

                if (displayHelper == null) {
                    displayHelper = DisplayHelper(context)
                }

                displayHelper?.attach(view, modelViewer?.engine)
                modelViewer?.render()
            }
        )
    }
}

private fun SurfaceView(context: Context) = android.view.SurfaceView(context).apply {
    holder.addCallback(object : android.view.SurfaceHolder.Callback {
        override fun surfaceCreated(holder: android.view.SurfaceHolder) {}
        override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {}
        override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {}
    })
}

private fun ModelViewer.loadModelGlb(assets: AssetManager, url: String) {
    val buffer = assets.open(url).use { input ->
        val bytes = input.readBytes()
        ByteBuffer.allocateDirect(bytes.size)
            .order(ByteOrder.nativeOrder())
            .put(bytes)
            .flip()
    }
    loadGlb(buffer)
}

private fun ModelViewer.transformToUnitCube() {
    val aabb = asset?.root?.boundingBox
    if (aabb != null) {
        val center = aabb.center
        val extent = aabb.extent
        val scale = 1.0f / maxOf(extent.x, extent.y, extent.z)
        val transform = FloatBuffer.allocate(16).apply {
            put(floatArrayOf(
                scale, 0f, 0f, 0f,
                0f, scale, 0f, 0f,
                0f, 0f, scale, 0f,
                -center.x * scale, -center.y * scale, -center.z * scale, 1f
            ))
        }
        asset?.root?.transform = transform
    }
}

@Composable
fun Model3dViewer(
    modelUrl: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val modelViewer = remember { createModelViewer(context) }

    DisposableEffect(modelUrl) {
        loadModel(context, modelViewer, modelUrl)
        onDispose {
            modelViewer.destroy()
        }
    }

    AndroidView(
        factory = { context ->
            SurfaceView(context).apply {
                modelViewer.attachToSurfaceView(this)
            }
        },
        modifier = modifier,
        update = { view ->
            modelViewer.render()
        }
    )
}

private fun createModelViewer(context: Context): ModelViewer {
    Utils.init()
    val engine = Engine.create()
    val renderer = engine.createRenderer()
    val scene = engine.createScene()
    val camera = engine.createCamera(engine.entityManager.create())
    val view = engine.createView()

    view.scene = scene
    view.camera = camera

    return ModelViewer(engine, camera, view, scene)
}

private fun loadModel(context: Context, modelViewer: ModelViewer, modelUrl: String) {
    try {
        val inputStream = context.assets.open("3d_models/$modelUrl")
        val buffer = ByteBuffer.allocateDirect(inputStream.available())
        buffer.order(ByteOrder.nativeOrder())
        Channels.newInputStream(inputStream).use { it.read(buffer.array()) }
        buffer.rewind()

        modelViewer.loadGlb(buffer)
        modelViewer.transformToUnitCube()
    } catch (e: Exception) {
        e.printStackTrace()
    }
} 