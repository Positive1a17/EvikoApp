package com.eviko.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.eviko.app.data.dao.CategoryDao
import com.eviko.app.data.dao.ProductDao
import com.eviko.app.data.dao.UserDao
import com.eviko.app.data.models.Category
import com.eviko.app.data.models.Product
import com.eviko.app.data.models.User
import com.eviko.app.data.models.UserRole

/**
 * Основной класс базы данных приложения.
 * Использует Room для хранения данных.
 */
@Database(
    entities = [
        User::class,
        Product::class,
        Category::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun productDao(): ProductDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        /**
         * Миграция с версии 1 на версию 2.
         * Добавляет поле isNew в таблицу products.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN isNew INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * Миграция с версии 2 на версию 3.
         * Добавляет поле rating в таблицу products.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN rating REAL NOT NULL DEFAULT 0.0")
            }
        }

        /**
         * Миграция с версии 3 на версию 4.
         * Добавляет поле discount в таблицу products.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN discount INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
}

class Converters {
    @androidx.room.TypeConverter
    fun fromUserRole(value: UserRole): String = value.name

    @androidx.room.TypeConverter
    fun toUserRole(value: String): UserRole = UserRole.valueOf(value)
} 