package com.eviko.app.data.repositories

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CartRepository @Inject constructor() {
    private val _cartItems = MutableStateFlow<Map<String, Int>>(emptyMap())
    val cartItems: StateFlow<Map<String, Int>> = _cartItems.asStateFlow()

    fun addToCart(productId: String) {
        val currentItems = _cartItems.value.toMutableMap()
        currentItems[productId] = (currentItems[productId] ?: 0) + 1
        _cartItems.value = currentItems
    }

    fun removeFromCart(productId: String) {
        val currentItems = _cartItems.value.toMutableMap()
        currentItems.remove(productId)
        _cartItems.value = currentItems
    }

    fun updateQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            removeFromCart(productId)
        } else {
            val currentItems = _cartItems.value.toMutableMap()
            currentItems[productId] = quantity
            _cartItems.value = currentItems
        }
    }

    fun getQuantity(productId: String): Int = _cartItems.value[productId] ?: 0

    fun clearCart() {
        _cartItems.value = emptyMap()
    }

    fun getTotalItems(): Int = _cartItems.value.values.sum()
} 