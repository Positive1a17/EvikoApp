package com.eviko.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun NewsScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Новые поступления:",
                style = MaterialTheme.typography.titleLarge
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(brandLogos) { brandLogo ->
                    BrandLogoItem(brandLogo)
                }
            }
        }

        items(newsItems) { newsItem ->
            NewsCard(newsItem)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewsCard(newsItem: NewsItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        onClick = { /* TODO: Открыть детали */ }
    ) {
        Column {
            Image(
                painter = painterResource(id = newsItem.imageRes),
                contentDescription = newsItem.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = newsItem.title,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = newsItem.description,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
                if (newsItem.price != null) {
                    Text(
                        text = "${newsItem.price} €",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BrandLogoItem(brandLogo: BrandLogo) {
    Card(
        modifier = Modifier.size(80.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Image(
            painter = painterResource(id = brandLogo.logoRes),
            contentDescription = brandLogo.name,
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize(),
            contentScale = ContentScale.Fit
        )
    }
}

private data class NewsItem(
    val imageRes: Int,
    val title: String,
    val description: String,
    val price: Int? = null
)

private data class BrandLogo(
    val logoRes: Int,
    val name: String
)

// Примеры данных (замените на реальные ресурсы)
private val brandLogos = listOf(
    BrandLogo(android.R.drawable.ic_menu_gallery, "Nike"),
    BrandLogo(android.R.drawable.ic_menu_gallery, "New Balance"),
    BrandLogo(android.R.drawable.ic_menu_gallery, "Adidas"),
    BrandLogo(android.R.drawable.ic_menu_gallery, "Jordan")
)

private val newsItems = listOf(
    NewsItem(
        android.R.drawable.ic_menu_gallery,
        "Air Jordan 4 RM \"Hemp\"",
        "Surprise Drop bei Nike!",
        315
    ),
    NewsItem(
        android.R.drawable.ic_menu_gallery,
        "adidas BW Army Sneaker",
        "Restock des Klassikers in 3 Colourways!",
        170
    )
) 