package com.eviko.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.eviko.app.R
import com.eviko.app.ui.viewmodels.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    viewModel: MainViewModel
) {
    var selectedLanguage by remember { mutableStateOf(viewModel.getCurrentLanguage()) }
    var selectedTheme by remember { mutableStateOf(viewModel.getCurrentTheme()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = stringResource(R.string.language),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedLanguage == "ru",
                    onClick = {
                        selectedLanguage = "ru"
                        viewModel.setLanguage("ru")
                    },
                    label = { Text(stringResource(R.string.russian)) }
                )

                FilterChip(
                    selected = selectedLanguage == "en",
                    onClick = {
                        selectedLanguage = "en"
                        viewModel.setLanguage("en")
                    },
                    label = { Text(stringResource(R.string.english)) }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = stringResource(R.string.theme),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedTheme == "light",
                    onClick = {
                        selectedTheme = "light"
                        viewModel.setTheme("light")
                    },
                    label = { Text(stringResource(R.string.light)) }
                )

                FilterChip(
                    selected = selectedTheme == "dark",
                    onClick = {
                        selectedTheme = "dark"
                        viewModel.setTheme("dark")
                    },
                    label = { Text(stringResource(R.string.dark)) }
                )

                FilterChip(
                    selected = selectedTheme == "system",
                    onClick = {
                        selectedTheme = "system"
                        viewModel.setTheme("system")
                    },
                    label = { Text(stringResource(R.string.system)) }
                )
            }
        }
    }
} 