package com.eviko.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    isUserLoggedIn: Boolean = false
) {
    val navController = rememberNavController()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (navController.currentBackStackEntryAsState().value?.destination?.route) {
                            "home" -> "Eviko"
                            "showcase" -> "Витрина"
                            "chat" -> "Чат"
                            "profile" -> if (isUserLoggedIn) "Профиль" else "Вход"
                            else -> "Eviko"
                        }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                listOf(
                    NavigationItem("home", "Главная", Icons.Default.Home),
                    NavigationItem("showcase", "Витрина", Icons.Default.GridView),
                    NavigationItem("chat", "Чат", Icons.Default.Chat),
                    NavigationItem("profile", "Профиль", Icons.Default.Person)
                ).forEach { item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("home") { HomeScreen() }
            composable("showcase") { ShowcaseScreen() }
            composable("chat") { ChatScreen() }
            composable("profile") { 
                if (isUserLoggedIn) {
                    ProfileScreen(
                        onLogout = { /* TODO: Implement logout */ }
                    )
                } else {
                    AuthScreen(
                        onLogin = { /* TODO: Implement login */ },
                        onRegister = { /* TODO: Implement register */ },
                        onSkip = { /* TODO: Continue as guest */ }
                    )
                }
            }
        }
    }
}

private data class NavigationItem(
    val route: String,
    val title: String,
    val icon: ImageVector
) 