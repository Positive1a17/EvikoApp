package com.eviko.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PinCodeScreen(
    onPinComplete: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    val maxLength = 4

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(32.dp)
    ) {
        Spacer(modifier = Modifier.height(64.dp))
        
        Text(
            text = "Введите PIN-код",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        // PIN dots indicator
        Row(
            modifier = Modifier
                .padding(vertical = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            repeat(maxLength) { index ->
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(
                            if (index < pin.length) 
                                MaterialTheme.colorScheme.primary
                            else 
                                MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        // Number pad
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            (1..9).chunked(3).forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    row.forEach { number ->
                        PinButton(
                            number = number.toString(),
                            onClick = {
                                if (pin.length < maxLength) {
                                    pin += number
                                    if (pin.length == maxLength) {
                                        onPinComplete(pin)
                                    }
                                }
                            }
                        )
                    }
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                PinButton(
                    number = "",
                    onClick = { }
                )
                PinButton(
                    number = "0",
                    onClick = {
                        if (pin.length < maxLength) {
                            pin += "0"
                            if (pin.length == maxLength) {
                                onPinComplete(pin)
                            }
                        }
                    }
                )
                PinButton(
                    number = "⌫",
                    onClick = {
                        if (pin.isNotEmpty()) {
                            pin = pin.dropLast(1)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun PinButton(
    number: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(72.dp),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
    ) {
        Text(
            text = number,
            fontSize = 24.sp,
            textAlign = TextAlign.Center
        )
    }
} 