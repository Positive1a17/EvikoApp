package com.eviko.app.data.repositories

import androidx.lifecycle.ViewModel
import javax.inject.Inject
import javax.inject.Singleton
import com.eviko.app.data.models.Product
import dagger.hilt.android.lifecycle.HiltViewModel

@HiltViewModel
class ProductRepository @Inject constructor() : ViewModel() {
    // Временные данные для демонстрации
    private val products = listOf(
        Product(
            id = "1",
            name = "Смартфон",
            description = "Современный смартфон с мощным процессором",
            price = 999.99,
            category = "Электроника"
        ),
        Product(
            id = "2",
            name = "Ноутбук",
            description = "Легкий и мощный ноутбук для работы",
            price = 1499.99,
            category = "Электроника"
        ),
        Product(
            id = "3",
            name = "Наушники",
            description = "Беспроводные наушники с шумоподавлением",
            price = 199.99,
            category = "Аксессуары"
        )
    )

    private val categories = listOf("Электроника", "Аксессуары", "Одежда")

    fun getAllProducts(): List<Product> = products

    fun getProductById(id: String): Product? = products.find { it.id == id }

    fun getCategories(): List<String> = categories

    fun searchProducts(query: String): List<Product> {
        return products.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.description.contains(query, ignoreCase = true)
        }
    }

    fun getProductsByCategory(category: String): List<Product> {
        return products.filter { it.category == category }
    }
} 