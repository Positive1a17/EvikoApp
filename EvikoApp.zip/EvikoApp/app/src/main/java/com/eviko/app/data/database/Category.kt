package com.eviko.app.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Сущность категории в базе данных.
 */
@Entity(tableName = "categories")
data class Category(
    @PrimaryKey
    val id: Long,
    val name: String,
    val description: String
) 