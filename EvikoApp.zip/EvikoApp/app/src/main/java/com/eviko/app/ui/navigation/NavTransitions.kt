package com.eviko.app.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween

fun enterTransition() = fadeIn(animationSpec = tween(300)) + 
    slideInHorizontally(animationSpec = tween(300)) { fullWidth -> fullWidth }

fun exitTransition() = fadeOut(animationSpec = tween(300)) + 
    slideOutHorizontally(animationSpec = tween(300)) { fullWidth -> -fullWidth }

fun popEnterTransition() = fadeIn(animationSpec = tween(300)) + 
    slideInHorizontally(animationSpec = tween(300)) { fullWidth -> -fullWidth }

fun popExitTransition() = fadeOut(animationSpec = tween(300)) + 
    slideOutHorizontally(animationSpec = tween(300)) { fullWidth -> fullWidth } 