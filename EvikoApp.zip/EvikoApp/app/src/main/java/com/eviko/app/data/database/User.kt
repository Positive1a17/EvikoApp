package com.eviko.app.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Сущность пользователя в базе данных.
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val id: Long,
    val email: String,
    val passwordHash: Int,
    val name: String,
    val role: UserRole
)

/**
 * Роли пользователей в системе.
 */
enum class UserRole {
    USER,
    ADMIN
} 